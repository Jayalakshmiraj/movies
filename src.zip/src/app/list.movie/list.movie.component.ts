import { Component, OnInit } from '@angular/core';
import { MovieService } from 'src/app/movie.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-list.movie',
  templateUrl: './list.movie.component.html',
  styleUrls: ['./list.movie.component.scss'],
})
export class ListMovieComponent implements OnInit {
movies=[];
  constructor(private movieService:MovieService,private router:Router) { }

  ngOnInit() {
    this.movieService.getRemoteCustomers().subscribe((result) => {this.movies = result;});
  }
  deleteMovie(movie){
   
    this.movieService.deleteRemoteMovie(movie).subscribe((e) => {
      
      this.movieService.getDBMovies().subscribe((result) => {
       
        this.movies = result;});
    });
   // this.list = this.customerService.getCustomers();
  }
  editMovie(movie){
    this.router.navigate(['/edit-movie/'+movie.id]);
  }
}

