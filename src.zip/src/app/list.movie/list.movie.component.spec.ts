import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { List.MovieComponent } from './list.movie.component';

describe('List.MovieComponent', () => {
  let component: List.MovieComponent;
  let fixture: ComponentFixture<List.MovieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ List.MovieComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(List.MovieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
