import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { MovieComponent } from './movie/movie.component';
import { ListMovieComponent } from './list.movie/list.movie.component';
import { AddMovieComponent } from './add.movie/add.movie.component';
import { EditMovieComponent } from './edit.movie/edit.movie.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path:'movie',component:MovieComponent},
  {path:'add-movie',component:AddMovieComponent},
  {path:'list-movie',component:ListMovieComponent},
  {path:'edit-movie/:id',component:EditMovieComponent},
  {path:'register',component:RegisterComponent},

  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
