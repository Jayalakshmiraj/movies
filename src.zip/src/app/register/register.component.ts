import { Component, OnInit } from '@angular/core';
import {MovieService} from '../movie.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {

  
  customer={name:"",password:"",address:"",email:"",phone:""};
  constructor(private router:Router,private movieService:MovieService) { }

  ngOnInit() {}
  loginIn(customer){
  console.log(customer)
    this.movieService.addRemoteCustomer(this.customer).
    subscribe(()=> this.router.navigate(['./home']));
  }
}
