import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  Movies=[];
  private movieUrl = 'http://localhost:3000/api/movies';
  private customerUrl = 'http://localhost:3000/api/customers';

  constructor(private http: HttpClient) { }
  getDBMovies (){
    
  return  this.http.get<[any]>(this.movieUrl)

}
getCustomers(): Observable<[]>{
  return this.http.get<[]>(this.customerUrl); 		
}
getRemoteCustomers(): Observable<[any]>{
  return this.http.get<[any]>(this.movieUrl); 		
}
deleteRemoteMovie(movie){
 
  return this.http.delete(this.movieUrl+"/"+movie.id); 		
}
addRemoteMovie(movie):Observable<any>{
  return this.http.post(this.movieUrl,movie);
}
updateRemoteMovie(movie):Observable<any>{
  return this.http.put(this.movieUrl + "/"+movie.id,movie);
}

getRemoteMovieById(id):Observable<any>{
  console.log(this.movieUrl);
 return this.http.get<[any]>(this.movieUrl + "/"+id);
}
addRemoteCustomer(customer): Observable<any>{
  return this.http.post(this.customerUrl,customer);
 }
}
