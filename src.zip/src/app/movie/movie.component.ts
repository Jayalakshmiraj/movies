import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.scss'],
})
export class MovieComponent implements OnInit {
  private selectedItem: any;
  private icons = [
    'people',
    'person-add',
  ];
  public items: Array<{ title: string; note: string; icon: string }> = [];
  constructor(private router: Router) {
  	this.items.push({
  		title: 'List',
        note:'/list-movie',
        icon: this.icons[0]
    });
    this.items.push({
  		title: 'Add',
        note:'/add-movie',
        icon: this.icons[1]
  	});
  
  }
  openUrl(item){
    this.router.navigate([item.note]);
  }

 

  ngOnInit() {}

}
