import { Component, OnInit } from '@angular/core';
import { MovieService } from 'src/app/movie.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-add.movie',
  templateUrl: './add.movie.component.html',
  styleUrls: ['./add.movie.component.scss'],
})
export class AddMovieComponent implements OnInit {
  movies = {name:'', year:'', image_url:'', production_house:'', rating:'', type:'',language:'',date:''};
  constructor(private movieService: MovieService, private router: Router) { }

  ngOnInit() {}
  addMovie(){
  	this.movieService.addRemoteMovie(this.movies).subscribe(()=>{this.router.navigate(['/list-movie']);});
  }

}
