import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {MovieService} from '../movie.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  customer={name:"",password:"",address:"",email:"",phone:""}
customers=[];
  constructor(private router:Router,private movieService:MovieService)
    { }
    ngOnInit() {
      this.movieService.getCustomers().
      subscribe((result) => {this.customers = result;});
    }
    login(customer){
      for(var i=0;i<this.customers.length;i++)
      {
        if((this.customer.email==this.customers[i].email) && (this.customer.password==this.customers[i].password)){
          this.router.navigate(['list-movie']);
          break;
        }
      }
    }
  createAccount(){
    this.router.navigate(['register'])
  }
}

